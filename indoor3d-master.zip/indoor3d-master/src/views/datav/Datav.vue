<template>
    <div class="datav">

        <div class="wpbox">

            <!-- bnt end -->
            <div class="left1">
                <div class="aleftboxttop">
                    <h2 class="title">项目对比</h2>
                    <div class="lefttoday_tit" style=" height:8%">
                        <p class="fm">周期:每日</p>
                        <p class="fr">2018-06-14</p>
                    </div>
                    <div class="tlbox">
                        dasdasdasda
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                    </div>
                </div>

            </div>
        </div>






        <!-- 项目 工资发放
        民工 项目 工资反馈
        班组 消息滚动 -->






    </div>
</template>

<style scoped lang="less" src="./Datav.less" />
<script lang='ts' src="./Datav.ts" />