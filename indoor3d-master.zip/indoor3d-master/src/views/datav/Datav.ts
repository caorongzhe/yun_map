import { Options, Vue } from 'vue-class-component';

export default class Datav extends Vue {

}