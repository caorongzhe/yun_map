import { Options, Vue } from 'vue-class-component';
import { Graph, Cell, Node, Color, Dom } from '@antv/x6'
import dagre from 'dagre'
export default class Data extends Vue {
    graph: any;

    xxx() {

        let container: any = document.getElementById('container');
        // 自定义节点
        Graph.registerNode(
            'org-node',
            {
                width: 360,
                height: 120,
                markup: [
                    {
                        tagName: 'rect',
                        attrs: {
                            class: 'card',
                        },
                    },
                    {
                        tagName: 'text',
                        attrs: {
                            class: 'name',
                        },
                    },
                    {
                        tagName: 'text',
                        attrs: {
                            class: 'role',
                        },
                    },

                ],
                attrs: {
                    '.card': {
                        rx: 10,
                        ry: 10,
                        refWidth: '100%',
                        refHeight: '100%',
                        fill: '#fff',
                        pointerEvents: 'visiblePainted',
                    },
                    '.name': {
                        refX: 0.05,
                        refY: 0.15,
                        fontSize: 20,
                        textAnchor: 'left',
                        textVerticalAnchor: 'top',
                    },
                    '.role': {
                        refX: 0.95,
                        refY: 0.75,
                        fontSize: 16,
                        fontWeight: '600',
                        textAnchor: 'end',
                    },
                },
            },
            true,
        )

        // 自定义边
        Graph.registerEdge(
            'org-edge',
            {
                zIndex: -1,
                attrs: {
                    line: {
                        stroke: '#585858',
                        strokeWidth: 3,
                        sourceMarker: null,
                        targetMarker: null,
                    },
                },
            },
            true,
        )

        // 创建画布
        this.graph = new Graph({
            container: container,
            grid: true,
            width: 1800,
            height: 800,
            interacting: false,
            panning: {
                enabled: true,
                eventTypes: ['leftMouseDown', 'rightMouseDown', 'mouseWheel']
            },

        })
    }

    // 树形结构
    dir: any = 'TB' // LR RL TB BT
    layout() {
        const nodes = this.graph.getNodes()
        const edges = this.graph.getEdges()
        const g = new dagre.graphlib.Graph()
        g.setGraph({ rankdir: this.dir, nodesep: 30, ranksep: 60 })
        g.setDefaultEdgeLabel(() => ({}))

        const width = 360
        const height = 120
        nodes.forEach((node: any) => {
            g.setNode(node.id, { width, height })
        })

        edges.forEach((edge: any) => {
            const source = edge.getSource()
            const target = edge.getTarget()
            g.setEdge(source.cell, target.cell)
        })

        dagre.layout(g)
        this.graph.freeze()
        g.nodes().forEach((id) => {
            const node = this.graph.getCell(id) as Node
            if (node) {
                const pos = g.node(id)
                node.position(pos.x, pos.y)
            }
        })

        edges.forEach((edge: any) => {
            const source = edge.getSourceNode()!
            const target = edge.getTargetNode()!
            const sourceBBox = source.getBBox()
            const targetBBox = target.getBBox()
            if ((this.dir === 'LR' || this.dir === 'RL') && sourceBBox.y !== targetBBox.y) {
                const gap =
                    this.dir === 'LR'
                        ? targetBBox.x - sourceBBox.x - sourceBBox.width
                        : -sourceBBox.x + targetBBox.x + targetBBox.width
                const fix = this.dir === 'LR' ? sourceBBox.width : 0
                const x = sourceBBox.x + fix + gap / 2
                edge.setVertices([
                    { x, y: sourceBBox.center.y },
                    { x, y: targetBBox.center.y },
                ])
            } else if (
                (this.dir === 'TB' || this.dir === 'BT') &&
                sourceBBox.x !== targetBBox.x
            ) {
                const gap =
                    this.dir === 'TB'
                        ? targetBBox.y - sourceBBox.y - sourceBBox.height
                        : -sourceBBox.y + targetBBox.y + targetBBox.height
                const fix = this.dir === 'TB' ? sourceBBox.height : 0
                const y = sourceBBox.y + fix + gap / 2
                edge.setVertices([
                    { x: sourceBBox.center.x, y },
                    { x: targetBBox.center.x, y },
                ])
            } else {
                edge.setVertices([])
            }
        })

        this.graph.unfreeze()
    }

    /**
     * 创建节点
     * @param name 名称
     * @param role 角色
     * @param background 背景颜色
     * @param textColor 字体颜色
     * @returns 返回节点
     */
    createNode(name: string, role: string, background: string, textColor = '#000') {
        return this.graph.createNode({
            shape: 'org-node',
            attrs: {
                '.card': { fill: background },
                '.name': {
                    fill: textColor,
                    text: Dom.breakText(name, { width: 265, height: 100 }),
                },
                '.role': {
                    fill: '#ef4136',
                    text: Dom.breakText(role, { width: 265, height: 100 }),
                }
            },
        })
    }

    createEdge(source: Cell, target: Cell) {
        return this.graph.createEdge({
            shape: 'org-edge',
            source: { cell: source.id },
            target: { cell: target.id },
        })
    }

    // 1、建设方，2、总承包，3、甲指分包，4、分包，5、劳务派遣
    nodes: Array<any> = new Array();
    edges: Array<any> = new Array();
    handle(data: any, node: any) {
        let role = this.getRole(data);
        if (!node) {
            node = this.createNode(data.name, role[0], role[1]);
        }
        this.nodes.push(node);
        const children = data.children;
        for (const iterator of children) {
            role = this.getRole(iterator);
            const childrenNode = this.createNode(data.name, role[0], role[1]);
            this.edges.push(this.createEdge(node, childrenNode));
            this.handle(iterator, childrenNode);
        }
    }

    /**
     * 获取项目角色
     * @param data 项目数据
     */
    getRole(data: any): any {
        switch (data.role) {
            case '1':
                return ["(建设方)", '#B1D283'];
            case '2':
                return ["(总承包)", '#95C8CB'];
            case '3':
                return ["(甲指分包)", '#B3DDDF'];
            case '4':
                return ["(分包)", '#F2C795'];
            case '5':
                return ["(劳务派遣)", '#F3E1B3'];
        }
    }

    mounted() {
        this.xxx();
        this.handle(this.data, undefined);
        //this.graph.resetCells([...nodes1, ...edges1])
        this.graph.resetCells([...this.nodes, ...this.edges])
        this.layout()
        this.graph.zoomTo(0.8)
        this.graph.centerContent()

    }

    data: any = {
        "id": "1472885871231635458",
        "workspace": "75b5b3ff-1969-41b5-a161-e15af132fdda",
        "name": "锦湘国际星城五期•绿之韵中心项目主体工程",
        "children": [
            {
                "id": "1473168895341314049",
                "workspace": "75b5b3ff-1969-41b5-a161-e15af132fdda",
                "name": "锦湘国际星城五期绿之韵中心项目屋面工程",
                "parentId": "1472885871231635458",
                "children": [
                    {
                        "id": "1473168895341314049",
                        "workspace": "75b5b3ff-1969-41b5-a161-e15af132fdda",
                        "name": "锦湘国际星城五期绿之韵中心项目屋面工程",
                        "parentId": "1472885871231635458",
                        "children": [
                            {
                                "id": "1473168895341314049",
                                "workspace": "75b5b3ff-1969-41b5-a161-e15af132fdda",
                                "name": "锦湘国际星城五期绿之韵中心项目屋面工程",
                                "parentId": "1472885871231635458",
                                "children": [

                                ],
                                "topId": "1472885871231635458",
                                "completionTime": "2022-12-31T16:00:00",
                                "capital": "0",
                                "role": "5",
                                "examineStatus": "2",
                                "authStatus": "2",
                                "completeStatus": "",
                                "schedule": 0,
                                "investigateStatus": "0",
                                "provinceCode": "11",
                                "cityCode": "1101",
                                "areaCode": "110101",
                                "streetCode": "110101001",
                                "address": "天安门",
                                "lng": "116.397499",
                                "lat": "39.908722",
                                "createBy": "1471036731560329218",
                                "createTime": "2021-12-21 13:50:09",
                                "updateTime": "2021-12-21 21:36:46",
                                "updateBy": "1471036731560329218",
                                "status": "1"
                            },
                            {
                                "id": "1473168895341314049",
                                "workspace": "75b5b3ff-1969-41b5-a161-e15af132fdda",
                                "name": "锦湘国际星城五期绿之韵中心项目屋面工程",
                                "parentId": "1472885871231635458",
                                "children": [

                                ],
                                "topId": "1472885871231635458",
                                "completionTime": "2022-12-31T16:00:00",
                                "capital": "0",
                                "role": "5",
                                "examineStatus": "2",
                                "authStatus": "2",
                                "completeStatus": "",
                                "schedule": 0,
                                "investigateStatus": "0",
                                "provinceCode": "11",
                                "cityCode": "1101",
                                "areaCode": "110101",
                                "streetCode": "110101001",
                                "address": "天安门",
                                "lng": "116.397499",
                                "lat": "39.908722",
                                "createBy": "1471036731560329218",
                                "createTime": "2021-12-21 13:50:09",
                                "updateTime": "2021-12-21 21:36:46",
                                "updateBy": "1471036731560329218",
                                "status": "1"
                            }
                        ],
                        "topId": "1472885871231635458",
                        "completionTime": "2022-12-31T16:00:00",
                        "capital": "0",
                        "role": "4",
                        "examineStatus": "2",
                        "authStatus": "2",
                        "completeStatus": "",
                        "schedule": 0,
                        "investigateStatus": "0",
                        "provinceCode": "11",
                        "cityCode": "1101",
                        "areaCode": "110101",
                        "streetCode": "110101001",
                        "address": "天安门",
                        "lng": "116.397499",
                        "lat": "39.908722",
                        "createBy": "1471036731560329218",
                        "createTime": "2021-12-21 13:50:09",
                        "updateTime": "2021-12-21 21:36:46",
                        "updateBy": "1471036731560329218",
                        "status": "1"
                    }
                ],
                "topId": "1472885871231635458",
                "completionTime": "2022-12-31T16:00:00",
                "capital": "0",
                "role": "2",
                "examineStatus": "2",
                "authStatus": "2",
                "completeStatus": "",
                "schedule": 0,
                "investigateStatus": "0",
                "provinceCode": "11",
                "cityCode": "1101",
                "areaCode": "110101",
                "streetCode": "110101001",
                "address": "天安门",
                "lng": "116.397499",
                "lat": "39.908722",
                "createBy": "1471036731560329218",
                "createTime": "2021-12-21 13:50:09",
                "updateTime": "2021-12-21 21:36:46",
                "updateBy": "1471036731560329218",
                "status": "1"
            },
            {
                "id": "1473182955751391233",
                "workspace": "75b5b3ff-1969-41b5-a161-e15af132fdda",
                "name": "锦湘国际星城五期绿之韵中心项目屋面工程",
                "parentId": "1472885871231635458",
                "children": [
                    {
                        "id": "1473168895341314049",
                        "workspace": "75b5b3ff-1969-41b5-a161-e15af132fdda",
                        "name": "锦湘国际星城五期绿之韵中心项目屋面工程",
                        "parentId": "1472885871231635458",
                        "children": [
                            {
                                "id": "1473168895341314049",
                                "workspace": "75b5b3ff-1969-41b5-a161-e15af132fdda",
                                "name": "锦湘国际星城五期绿之韵中心项目屋面工程",
                                "parentId": "1472885871231635458",
                                "children": [

                                ],
                                "topId": "1472885871231635458",
                                "completionTime": "2022-12-31T16:00:00",
                                "capital": "0",
                                "role": "5",
                                "examineStatus": "2",
                                "authStatus": "2",
                                "completeStatus": "",
                                "schedule": 0,
                                "investigateStatus": "0",
                                "provinceCode": "11",
                                "cityCode": "1101",
                                "areaCode": "110101",
                                "streetCode": "110101001",
                                "address": "天安门",
                                "lng": "116.397499",
                                "lat": "39.908722",
                                "createBy": "1471036731560329218",
                                "createTime": "2021-12-21 13:50:09",
                                "updateTime": "2021-12-21 21:36:46",
                                "updateBy": "1471036731560329218",
                                "status": "1"
                            },
                            {
                                "id": "1473168895341314049",
                                "workspace": "75b5b3ff-1969-41b5-a161-e15af132fdda",
                                "name": "锦湘国际星城五期绿之韵中心项目屋面工程",
                                "parentId": "1472885871231635458",
                                "children": [

                                ],
                                "topId": "1472885871231635458",
                                "completionTime": "2022-12-31T16:00:00",
                                "capital": "0",
                                "role": "5",
                                "examineStatus": "2",
                                "authStatus": "2",
                                "completeStatus": "",
                                "schedule": 0,
                                "investigateStatus": "0",
                                "provinceCode": "11",
                                "cityCode": "1101",
                                "areaCode": "110101",
                                "streetCode": "110101001",
                                "address": "天安门",
                                "lng": "116.397499",
                                "lat": "39.908722",
                                "createBy": "1471036731560329218",
                                "createTime": "2021-12-21 13:50:09",
                                "updateTime": "2021-12-21 21:36:46",
                                "updateBy": "1471036731560329218",
                                "status": "1"
                            },
                            {
                                "id": "1473168895341314049",
                                "workspace": "75b5b3ff-1969-41b5-a161-e15af132fdda",
                                "name": "锦湘国际星城五期绿之韵中心项目屋面工程",
                                "parentId": "1472885871231635458",
                                "children": [

                                ],
                                "topId": "1472885871231635458",
                                "completionTime": "2022-12-31T16:00:00",
                                "capital": "0",
                                "role": "5",
                                "examineStatus": "2",
                                "authStatus": "2",
                                "completeStatus": "",
                                "schedule": 0,
                                "investigateStatus": "0",
                                "provinceCode": "11",
                                "cityCode": "1101",
                                "areaCode": "110101",
                                "streetCode": "110101001",
                                "address": "天安门",
                                "lng": "116.397499",
                                "lat": "39.908722",
                                "createBy": "1471036731560329218",
                                "createTime": "2021-12-21 13:50:09",
                                "updateTime": "2021-12-21 21:36:46",
                                "updateBy": "1471036731560329218",
                                "status": "1"
                            }
                        ],
                        "topId": "1472885871231635458",
                        "completionTime": "2022-12-31T16:00:00",
                        "capital": "0",
                        "role": "4",
                        "examineStatus": "2",
                        "authStatus": "2",
                        "completeStatus": "",
                        "schedule": 0,
                        "investigateStatus": "0",
                        "provinceCode": "11",
                        "cityCode": "1101",
                        "areaCode": "110101",
                        "streetCode": "110101001",
                        "address": "天安门",
                        "lng": "116.397499",
                        "lat": "39.908722",
                        "createBy": "1471036731560329218",
                        "createTime": "2021-12-21 13:50:09",
                        "updateTime": "2021-12-21 21:36:46",
                        "updateBy": "1471036731560329218",
                        "status": "1"
                    },
                    {
                        "id": "1473168895341314049",
                        "workspace": "75b5b3ff-1969-41b5-a161-e15af132fdda",
                        "name": "锦湘国际星城五期绿之韵中心项目屋面工程",
                        "parentId": "1472885871231635458",
                        "children": [

                        ],
                        "topId": "1472885871231635458",
                        "completionTime": "2022-12-31T16:00:00",
                        "capital": "0",
                        "role": "4",
                        "examineStatus": "2",
                        "authStatus": "2",
                        "completeStatus": "",
                        "schedule": 0,
                        "investigateStatus": "0",
                        "provinceCode": "11",
                        "cityCode": "1101",
                        "areaCode": "110101",
                        "streetCode": "110101001",
                        "address": "天安门",
                        "lng": "116.397499",
                        "lat": "39.908722",
                        "createBy": "1471036731560329218",
                        "createTime": "2021-12-21 13:50:09",
                        "updateTime": "2021-12-21 21:36:46",
                        "updateBy": "1471036731560329218",
                        "status": "1"
                    }
                ],
                "topId": "1472885871231635458",
                "completionTime": "2021-12-21T16:00:00",
                "capital": "100",
                "role": "3",
                "examineStatus": "1",
                "authStatus": "0",
                "completeStatus": "",
                "schedule": 0,
                "investigateStatus": "0",
                "provinceCode": "43",
                "cityCode": "4301",
                "areaCode": "430103",
                "streetCode": "430103009",
                "address": "天心嘉园",
                "lng": "112.982161",
                "lat": "28.101283",
                "createBy": "1471036731560329218",
                "createTime": "2021-12-21 14:46:02",
                "updateTime": "2021-12-22 11:52:24",
                "updateBy": "1471036731560329218",
                "status": "1"
            }
        ],
        "topId": "1472885871231635458",
        "completionTime": "2021-12-31T16:00:00",
        "capital": "3330",
        "role": "1",
        "examineStatus": "2",
        "authStatus": "1",
        "completeStatus": "",
        "schedule": 0,
        "investigateStatus": "0",
        "provinceCode": "43",
        "cityCode": "4301",
        "areaCode": "430103",
        "streetCode": "430103009",
        "address": "天心嘉园",
        "lng": "112.988339",
        "lat": "28.099239",
        "createBy": "1471036731560329218",
        "createTime": "2021-12-20 19:05:31",
        "updateTime": "2021-12-21 20:23:14",
        "updateBy": "1471036731560329218",
        "remark": "这是认真过的.......",
        "status": "1"
    };


}