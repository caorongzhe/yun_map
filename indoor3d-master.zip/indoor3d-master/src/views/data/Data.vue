<template>
    <div>
        <div id="container"></div>
    </div>
</template>

<style scoped lang="less" src="./Data.less"/>
<script lang='ts' src="./Data.ts" />