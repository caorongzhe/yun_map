<template>
    <div>
        <el-container>
            <el-header>
                <Header></Header>
            </el-header>
            <el-container>
                <el-aside>
                    <Aside></Aside>
                </el-aside>
                <el-main>
                    <div class="canvas" id="editor">
                        <canvas id="canvas" class="canvas"
                        @mousewheel="zoom"
                        @mousedown="onmouse_down"
                        @mouseup="mouse_up"
                        >浏览器不兼容</canvas>
                    </div>
                </el-main>
            </el-container>
        </el-container>
    </div>
</template>

<style scoped lang="less" src="./Home.less" />
<script lang='ts' src="./Home.ts" />