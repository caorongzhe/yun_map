import { Options, Vue } from 'vue-class-component';
import Switch from '@/util/Switch';
import MouseDown from '@/util/MouseDown';
import Mouse from '@/util/Mouse';
import Cleaning from '@/util/Cleaning';
import Magic from '@/util/Magic';
import Header from '@/components/header/Header.vue'; // @ is an alias to /src
import Aside from '@/components/aside/Aside.vue'; // @ is an alias to /src
@Options({
    components: {
        Header,
        Aside
    },
})

export default class Home extends Vue {

    // 鼠标工具类
    private mouse: Mouse = new Mouse();
    // 获取画布对象
    private canvas: any;
    private context: any;
    private img: any = new Image();
    private ratio: number = 1; // 图片宽高比率
    private imgXY: number[] = [0, 0]; // 图片宽高

    // 初始化模板
    loading() {
        var editor: any = document.getElementById("editor");
        this.canvas.width = editor.offsetWidth;  //宽度
        this.canvas.height = editor.offsetHeight;    //高度
        let _this = this;
        this.img.onload = function () {
            // 图片比率，通过比率计算出宽度
            _this.ratio = _this.img.width / _this.img.height;
            _this.context.clearRect(0, 0, _this.canvas.width, _this.canvas.height);
            _this.drawImage(_this.canvas.height);
        }
        this.img.src = require('../../assets/map.png');
    }

    /**
     * 渲染图片
     * @param height 高度
     */
    drawImage(height: any) {
        this.img.width = height * this.ratio;
        this.img.height = height;
        // 图片比率，通过比率计算出宽度
        this.context.drawImage(this.img, this.imgXY[0], this.imgXY[1], height * this.ratio, height);
    }

    /**
     * 鼠标滚轮放大图片
     */
    zoom(e: any) {
        if (this.mouse.mousewheel(e)) {
            this.drawImage(this.img.height - 10);
        } else {
            this.drawImage(this.img.height + 10);
        }
    };

    /**
     * 鼠标按下
     * @param e 事件对象
     */
    currentXY: any; // 图片坐标数组
    onmouse_down(e: any) {
        if (this.mouse.isSpace()) {
            this.currentXY = this.mouse.windowToCanvas(this.canvas, e.clientX, e.clientY);
            // 这里mouse_move必须是原有绑定的函数，如果是匿名函数则不适用此方法
            this.canvas.addEventListener("mousemove", this.mouse_move, false);
        } else if (Switch.DRAWING_MANUAL_MARKING) {
            // 点击屏幕绘制线条
            MouseDown.DRAWING_MANUAL_MARKING(e, this.mouse, this.canvas, this.context);
        } else {

            let magic: Magic = new Magic(this.mouse, this.canvas, this.context, e);

            this.context.fillStyle = "#FF0000";
            this.context.beginPath();
            //let fast = magic.quick();
            let fast = magic.fastY();
            let cleaning: Cleaning = new Cleaning();
            cleaning.setXY(fast);
            let arr = cleaning.sort();



            console.log('arr', JSON.stringify(arr));
            let num = 0;
            let _this = this;
            setInterval(function () {
                if (arr.length <= num) {
                    return;
                }
                _this.context.beginPath();
                _this.context.arc(arr[num][0], arr[num][1], 1, 0, 2 * Math.PI, false);
                _this.context.closePath();
                _this.context.fill();
                num++;
            }, 10);
            this.context.closePath();
            this.context.fill();

        }
    }

    /**
     * 鼠标抬起
     * @param e 事件对象
     */

    mouse_up(e: any) {
        // 这里 fn 必须是原有绑定的函数，否侧解除无效
        this.canvas.removeEventListener("mousemove", this.mouse_move);
    };

    /**
     * 鼠标移动
     * @param e 事件对象
     */
    mouse_move(e: any) {
        let shift = this.mouse.windowToCanvas(this.canvas, e.clientX, e.clientY);
        let x = shift.x - this.currentXY.x;
        let y = shift.y - this.currentXY.y;
        this.currentXY = shift;
        this.imgXY[0] += x;
        this.imgXY[1] += y;
        this.drawImage(this.img.height);
    }

    mounted() {
        this.canvas = document.getElementById('canvas');
        this.context = this.canvas.getContext('2d');
        this.loading();
        // 给按键加监听事件
        this.mouse.keying();
        // Storage.set("xixi", { "value": "这是什么呢？", "time": 0, "json": false }, 100);
        // console.log(Storage.get("xixi"));

    }

}