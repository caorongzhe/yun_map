/* 功能性菜单，功能不多，就没分开写，其实就是懒 */
<template>
    <div class="header">
        <div class="main">
            <div class="menu">
                <img src="@/assets/logo.png" alt="">
            </div>
            <div class="menu">
                <i class="iconfont icon-xinjian"></i>新建
            </div>
            <div class="menu">
                <i class="iconfont icon-icon"></i>编辑
            </div>
            <div class="menu">
                3D
            </div>
            <div class="menu">
                2D
            </div>
            <div class="menu">
                <i class="iconfont icon-zhucehuiyuan"></i>注册
            </div>
            <div class="menu">
                <i class="iconfont icon-guanyu"></i>关于
            </div>
        </div>
        <div class="sub">
            <div class="menu checked">
                <i class="iconfont icon-yidong"></i>
            </div>
            <div class="menu">
                <i class="iconfont icon-shanchu"></i>
            </div>
        </div>

    </div>
</template>

<style scoped lang="less" src="./Header.less" />
<script lang='ts' src="./Header.ts" />