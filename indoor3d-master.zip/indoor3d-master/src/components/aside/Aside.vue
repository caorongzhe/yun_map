<template>
    <div class="aside">

        <div>
            <div class="menu checked">
                <i class="iconfont icon-shubiao"></i>
            </div>
            <div class="menu">
                <i class="iconfont icon-taosuo"></i>
            </div>
            <div class="menu">
                <i class="iconfont icon-mobang-01"></i>
            </div>
            <div class="menu">
                <i class="iconfont icon-fuzhiwenzi"></i>
            </div>
        </div>

        <div class="user">
            <img src="@/assets/header.png" alt="">
        </div>


    </div>
</template>

<style scoped lang="less" src="./Aside.less" />
<script lang='ts' src="./Aside.ts" />