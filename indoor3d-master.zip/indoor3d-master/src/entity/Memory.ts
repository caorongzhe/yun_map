/**
 * 存储对象
 */
class Memory {

    /**
     * 存储的数据
     */
    private value!: any;

    /**
     * 存储的事件
     */
    private time!: number;

    /**
     * 是否是json格式
     */
    private second: number = 0;

    public getValue(): any {
        return this.value;
    }

    public setValue(value: any) {
        this.value = value;
    }

    public getTime(): number {
        return this.time;
    }

    public setTime(time: number) {
        this.time = time;
        if (time > 0) {
            this.second = Math.round(new Date().getTime() / 1000);
        }
    }

    public getSecond(): number {
        return this.second;
    }

    public setSecond(second: number): number {
        return this.second = second;
    }

    /**
     * @classdesc <p>为了彻底对象化</p> 数据转换
     * @param data 对象数据
     */
    public static to(data: any): Memory {
        let memory: Memory = new Memory();
        let obj: any = JSON.parse(data);
        memory.setValue(obj.value);
        memory.setTime(obj.time);
        memory.setSecond(obj.second);
        return memory;
    }
}
export default Memory;