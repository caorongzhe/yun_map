/**
 * 选择工具
 */
class Magic {

    /**
     * 数组记录已搜索坐标
     */
    private visited: any = new Array();

    /**
     * 容差值
     */
    private wrong: number = 10;
    /**
     * 鼠标对象
     */
    private mouse!: any;
    /**
     * 画板对象
     */
    private canvas!: any;
    /**
     * 上下文对象
     */
    private context!: any;
    /**
     * 事件对象
     */
    private e!: any;

    /**
     * @see 魔棒工具
     * @param mouse 鼠标工具对象
     * @param canvas 画板对象
     * @param context 上下文对象
     * @param e 事件对象
     */
    constructor(mouse: any, canvas: any, context: any, e: any) {
        this.mouse = mouse;
        this.canvas = canvas;
        this.context = context;
        this.e = e;
    }

    /**
     * @see 魔棒选择，推荐不规则图形使用，容易递归出错
     */
    public quick(): any {
        let xy = this.mouse.windowToCanvas(this.canvas, this.e.clientX, this.e.clientY);
        let image: any = [];

        // 用 map集合
        this.fill(image, xy.x, xy.y, this.colors(xy.x, xy.y), [xy.x, xy.y]);
        return this.visited;
    }

    /**
     * @see 以X坐标轴快速选择，仅限于矩形和点击圆形中间
     */
    public fastX(): any {
        let xy = this.mouse.windowToCanvas(this.canvas, this.e.clientX, this.e.clientY);
        let image: any = [];
        let num = 0;
        let orig = this.colors(xy.x, xy.y);
        while (num < 999) {
            // 获取下一个颜色
            let next: [number, number, number] = this.colors(xy.x + num, xy.y);
            if (!this.inArea(xy.x + num, xy.y) || !this.equal(orig, next)) {
                break;
            }
            this.fillXY(image, xy.x + num, xy.y, orig, true, [xy.x, xy.y]);
            num += 2;
        }
        num = 0;
        while (num < 999) {
            // 获取下一个颜色
            let next: [number, number, number] = this.colors(xy.x - num, xy.y);
            if (!this.inArea(xy.x - num, xy.y) || !this.equal(orig, next)) {
                break;
            }
            this.fillXY(image, xy.x - num, xy.y, orig, true, [xy.x, xy.y]);
            num += 2;
        }
        return this.visited;
    }
    /**
     * @see 以Y坐标轴快速选择，仅限于矩形和点击圆形中间
     */
    public fastY(): any {
        let xy = this.mouse.windowToCanvas(this.canvas, this.e.clientX, this.e.clientY);
        let image: any = [];
        let num = 0;
        let orig = this.colors(xy.x, xy.y);
        while (num < 999) {
            // 获取下一个颜色
            let next: [number, number, number] = this.colors(xy.x, xy.y + num);
            if (!this.inArea(xy.x, xy.y + num) || !this.equal(orig, next)) {
                break;
            }
            this.fillXY(image, xy.x, xy.y + num, orig, false, [xy.x, xy.y]);
            num += 2;
        }
        num = 0;
        while (num < 999) {
            // 获取下一个颜色
            let next: [number, number, number] = this.colors(xy.x, xy.y - num);
            if (!this.inArea(xy.x, xy.y - num) || !this.equal(orig, next)) {
                break;
            }
            this.fillXY(image, xy.x, xy.y - num, orig, false, [xy.x, xy.y]);
            num += 2;
        }
        return this.visited;
    }

    /**
    * @see 以XY轴为中心
    * @param image 所在坐标颜色
    * @param x 当前x坐标
    * @param y 当前y坐标
    * @param orig 原点颜色
    * @param flag true：以x坐标，false：以y坐标
    * @returns 是否是相同的颜色
    */
    private fillXY(image: any, x: number, y: number, orig: [number, number, number], flag: boolean, up: [number, number]): number {

        // 获取下一个颜色
        let next: [number, number, number] = this.colors(x, y);



        // 出界：超出数组边界
        if (!this.inArea(x, y)) {
            return 0;
        }
        // 已探索过的 origColor 区域
        let z = x + ',' + y;
        if (image.indexOf(z) > -1) {
            return 1;
        } else {
            image.push(z);
        }

        // 边缘
        if (!this.equal(orig, next)) {
            this.visited.push(up);
            return 1;
        }
        // 判断以什么轴为中心
        if (flag) {
            // 当前的误差要小于去除点的误差
            let num = -2;
            while (true && num <= 2) {
                if (!this.equal(orig, this.colors(x + num, y))) {
                    this.visited.push([x, y]);
                    break;
                }
                num += 2;
            }
            this.fillXY(image, x, y - 2, orig, flag, [x, y]);
            this.fillXY(image, x, y + 2, orig, flag, [x, y]);
        } else {
            // 当前的误差要小于去除点的误差
            let num = -2;
            while (true && num <= 2) {
                if (!this.equal(orig, this.colors(x, y + num))) {
                    this.visited.push([x, y]);
                    break;
                }
                num += 2;
            }
            this.fillXY(image, x - 2, y, orig, flag, [x, y]);
            this.fillXY(image, x + 2, y, orig, flag, [x, y]);
        }
        return 1;
    }

    /**
    * @see 递归瀑布
    * @param image 所在坐标颜色
    * @param x 当前x坐标
    * @param y 当前y坐标
    * @param orig 原点颜色
    * @returns 是否是相同的颜色
    */
    private fill(image: any, x: number, y: number, orig: [number, number, number], up: [number, number]): number {

        // 获取下一个颜色
        let next: [number, number, number] = this.colors(x, y);

        // 出界：超出数组边界
        if (!this.inArea(x, y)) {
            return 0;
        }
        // 已探索过的 origColor 区域
        let z = x + ',' + y;
        if (image.indexOf(z) > -1) {
            return 1;
        } else {
            image.push(z);
        }

        // 边缘
        if (!this.equal(orig, next)) {
            this.visited.push(up);
            return 1;
        }

        this.fill(image, x - 2, y, orig, [x, y]);
        this.fill(image, x + 2, y, orig, [x, y]);
        this.fill(image, x, y - 2, orig, [x, y]);
        this.fill(image, x, y + 2, orig, [x, y]);
        return 1;
    }

    /**
     * @see 出界：超出边界索引
     * @param image 所在坐标颜色
     * @param x 当前x坐标
     * @param y 当前y坐标
     * @returns 是否边界
     */
    private inArea(x: number, y: number): boolean {
        return x >= 0 && x < this.canvas.width
            && y >= 0 && y < this.canvas.height;
    }

    /**
     * @see 获取颜色数值
     * @returns 颜色数值，因为要设置容差，就返回数值
     */
    private colors(x: number, y: number): [number, number, number] {
        var pixel = this.context.getImageData(x, y, 1, 1).data;
        var red = pixel[0];
        var green = pixel[1];
        var blue = pixel[2];
        // rgb
        // console.log('rgb(' + red + ', ' + green + ', ' + blue + ')');
        // 16进制
        //console.log("#" + ((1 << 24) + (red << 16) + (green << 8) + blue).toString(16).slice(1));
        return [red, green, blue];
    }

    /**
     * @see 经过容错值的计算，判断颜色是否一样
     * @param up 上一个颜色
     * @param orig 下一个颜色
     * @returns 对比值
     */
    private equal(up: [number, number, number], orig: [number, number, number]): boolean {
        // 计算相差值
        let r: number = Math.abs(up[0] - orig[0]);
        let g: number = Math.abs(up[1] - orig[1]);
        let b: number = Math.abs(up[2] - orig[2]);
        // 容错值
        if (r <= this.wrong && g <= this.wrong && b <= this.wrong) {
            return true;
        }
        return false;
    }

    /**
     * @see 设置颜色容差
     * @param wrong 容差值
     */
    public setWrong(wrong: number) {
        this.wrong = wrong;
    }


}
export default Magic;