/**
 * 按钮功能开关
 */
class Switch {

    /** 绘图-手动划线 */
    public static DRAWING_MANUAL_MARKING: boolean = false;




}
export default Switch;