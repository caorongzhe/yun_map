import String from '@/util/String';

/**
 * 鼠标事件
 */
class Mouse {

    // 空格键是否按住
    private space: boolean = false;

    /**
     * @classdesc 判断鼠标滚轮上下滚动,上滚是 ture, 往下是 false
     * @param event 滚轮事件对象
     */
    mousewheel(event: any): boolean {
        let e: any = event || window.event;
        if (e.wheelDelta) {  //判断浏览器IE，谷歌滑轮事件
            if (e.wheelDelta > 0) { //当滑轮向上滚动时
                return true;
            }
            if (e.wheelDelta < 0) { //当滑轮向下滚动时
                return false;
            }
        } else {  //Firefox滑轮事件
            if (e.detail > 0) { //当滑轮向上滚动时
                return true;
            }
            if (e.detail < 0) { //当滑轮向下滚动时
                return false;
            }
        }
        return false;
    }

    /**
     * @classdesc 获取在画布上的坐标
     * @param e canvas对象
     * @param x 当前坐标X
     * @param y 当前坐标Y
     * @returns 画布坐标
     */
    windowToCanvas(e: any, x: number, y: number): any {
        //这个方法返回一个矩形对象，包含四个属性：left、top、right和bottom。分别表示元素各边与页面上边和左边的距离
        var box = e.getBoundingClientRect();
        return {
            x: x - box.left - (box.width - e.width) / 2,
            y: y - box.top - (box.height - e.height) / 2
        };
    }

    /**
     * @classdesc 按键监听事件
     */
    keying() {
        let _this = this;
        // 按下键盘按键
        document.onkeydown = function (event) {
            //事件对象兼容
            let e = event || window.event || arguments.callee.caller.arguments[0];
            // 判断是否是“空格键”
            if (String.equal(e.code, 'Space')) {
                _this.space = true;
            }
        }
        // 松开键盘按键
        document.onkeyup = function (event) {
            //事件对象兼容
            let e = event || window.event || arguments.callee.caller.arguments[0];
            // 判断是否是“空格键”
            if (String.equal(e.code, 'Space')) {
                _this.space = false;
            }
        }
    }
    /**
     * @classdesc 判断是否按住 “空格键”
     * @returns boolean
     */
    public isSpace(): boolean {
        return this.space;
    }
}
export default Mouse;