import Memory from '@/entity/Memory';

/**
 * 本地缓存工具
 */
class Storage {

    /**
     * @classdesc <p>数据本地缓存</p> <p>因为ts的方法重载和java不一样，只能这样写</p>
     * @param key 键
     * @param value 值
     * @param time 存储时间
     * @returns 是否成功
     */
    static set(key: any, value: any, time = 0): any {
        if (key.length == 0 || value.length == 0) {
            return false;
        }

        let memory: Memory = new Memory();
        memory.setValue(value);
        memory.setTime(time);

        // 存储对象
        localStorage.setItem(key, JSON.stringify(memory));
    };

    /**
     * @classdesc 获取存储的数据
     * @param key 键
     */
    static get(key: any): any {
        let data = localStorage.getItem(key);
        if (data) {
            let memory: Memory = Memory.to(data);
            if (memory.getTime() > 0) {
                // 判断是否过期
                let second: number = Math.round(new Date().getTime() / 1000) - memory.getTime();
                if (second < memory.getSecond()) {
                    return memory.getValue();
                } else {
                    Storage.del(key);
                }
            } else {
                return memory.getValue();
            }
        }
        return undefined;
    }

    /**
     * @classdesc 删除存储的数据
     * @param key 键
     */
    static del(key: any) {
        localStorage.removeItem(key);
    }
}
export default Storage;