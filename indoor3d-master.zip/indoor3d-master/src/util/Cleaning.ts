import { number } from "echarts";

/**
 * 数据清洗
 */
class Cleaning {


    private xy!: number[][];

    constructor() {
    }

    /**
     * @see 坐标按照线条排序
     * @param data 坐标集合
     * @returns 排序后的集合
     */
    public sort(): number[][] {
        for (let i = 0; i < this.xy.length - 1; i++) {
            // 求当前坐标和下一个坐标间距
            let range = this.range(this.xy[i], this.xy[i + 1]);
            let next = -1;
            let arr: number[] = this.xy[i + 1];
            // 循环计算其余坐标和当前坐标的距离
            for (let j = i; j < this.xy.length - 2; j++) {
                // 求当前坐标和其他坐标的间距
                let temp = this.range(this.xy[i], this.xy[j + 2]);
                if (range > temp) {
                    range = temp;
                    next = j + 2;
                    arr = this.xy[next];
                }
            }
            this.xy[next] = this.xy[i + 1];
            this.xy[i + 1] = arr;
        }
        return this.xy;
    }

    /**
     * @see 角度排序法，排矩形和圆形的边框坐标
     */
    public clockwise(): void {

        // TODO 计算多边形的中心点，最好是手动的点的那个点
        let center: number[] = this.getCenter();

        // 冒泡排序
        let arr: number[];
        for (let i = 0; i < this.xy.length - 1; i++) {
            for (let j = 0; j < this.xy.length - 1 - i; j++) {
                if (this.angle(this.xy[j], center) > this.angle(this.xy[j + 1], center)) {
                    arr = this.xy[j];
                    this.xy[j] = this.xy[j + 1];
                    this.xy[j + 1] = arr;
                }
            }
        }
    }

    /**
     * @classdesc 根据三点去中间的原则清洗
     * @param data 坐标集合
     * @returns 清洗后的集合
     */
    private clean(data: any): any {

        // TODO 清洗数据

        return null;
    }

    /**
     * @see 获取矩形的中心坐标点
     * @returns 中心坐标点
     */
    private getCenter(): number[] {
        let x: number = 0;
        let y: number = 0;
        for (const xy in this.xy) {
            x += parseInt(xy[0]);
            y += parseInt(xy[1]);
        }
        return [x / this.xy.length, y / this.xy.length];
    }

    /**
     * @see 求坐标点和x轴的夹角度数
     * @param xy 坐标点
     * @param center 中心点
     * @returns 角度
     */
    private angle(xy: number[], center: number[]): number {
        //弧度
        let angle: number = Math.atan2((xy[1] - center[1]), (xy[0] - center[0]));
        //角度
        return angle * (360 / Math.PI);
    }

    /**
     * @see 计算两个坐标点的距离
     * @param orig 原点数据
     * @param go 去向数据
     * @returns 距离
     */
    private range(orig: number[], go: number[]): number {
        // 勾股定理
        let range = Math.sqrt(Math.abs(Math.pow((orig[0] - go[0]), 2) + Math.pow((orig[1] - go[1]), 2)));
        return range;
    }



    public setXY(xy: number[][]) {
        this.xy = xy;
    }

}
export default Cleaning;