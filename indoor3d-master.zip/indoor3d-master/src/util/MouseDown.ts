
import Mouse from '@/util/Mouse';
import Dot from '@/util/Dot';
/**
 * 点击鼠标事件
 */
class MouseDown {

    /**
     * @classdesc 点击屏幕绘制线条（绘图-手动划线）
     * @param e 鼠标事件对象
     * @param mouse 鼠标工具对象
     * @param canvas 画板对象
     * @param context 绘制上下文对象
     */
    public static DRAWING_MANUAL_MARKING(e: any, mouse: Mouse, canvas: any, context: any) {
        // 获取坐标在“canvas”点击的位置，创建一个点
        let arr: any = mouse.windowToCanvas(canvas, e.clientX, e.clientY);
        // 添加
        Dot.add(arr);
        // 绘制线条
        let array = Dot.get();
        const xy = array[array.length - 1];
        if (array.length === 1) {
            context.moveTo(xy.x, xy.y);
        } else {
            context.lineTo(xy.x, xy.y);
        }
        context.lineWidth = 2;
        context.strokeStyle = "red";
        context.stroke();
    }

}
export default MouseDown;