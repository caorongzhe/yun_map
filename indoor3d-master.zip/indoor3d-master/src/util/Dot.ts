class Dot {

    /**
     * 点的集合
     */
    static list: any = [];

    /**
     * @classdesc 添加点
     * @param arr 坐标
     */
    public static add(arr: any) {
        Dot.list.push(arr);
    }

    /**
     * @classdesc 获取点
     * @param key 键
     * @returns 点集合
     */
    public static get(key: any = false): any {
        if (key) {
            return undefined;
        } else {
            return Dot.list;
        }
    }

    /**
     * @classdesc 根据图片缩放比率，重新计算画过的坐标点
     * @param zoom 图片缩放比率
     */
    public static zoom(zoom: number) {

    }

    /**
     * @classdesc 根据图片移动比率，重新计算画过的坐标点
     * @param move 图片移动比率
     */
    public static move(move: number) {

    }



}
export default Dot;